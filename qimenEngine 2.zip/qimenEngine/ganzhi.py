"""
奇门遁甲干支计算模块
实现精确的年月日时干支计算，包括节气换月、五虎遁年起月法、五鼠遁日起时法等
"""

from datetime import datetime, timedelta
from typing import Tuple, Dict, Optional
from functools import lru_cache

try:
    from symbols import TIAN_GAN, DI_ZHI, SOLAR_TERMS
    from astronomical import astro_calculator
except ImportError:
    from .symbols import TIAN_GAN, DI_ZHI, SOLAR_TERMS
    from .astronomical import astro_calculator


class GanZhiCalculator:
    """干支计算器"""
    
    # 五虎遁年起月表（甲己年起丙寅，乙庚年起戊寅...）
    YEAR_MONTH_GAN_TABLE = {
        0: 2, 4: 2,  # 甲年、己年起丙寅月（丙=2）
        1: 4, 5: 4,  # 乙年、庚年起戊寅月（戊=4）
        2: 6, 6: 6,  # 丙年、辛年起庚寅月（庚=6）
        3: 8, 7: 8,  # 丁年、壬年起壬寅月（壬=8）
        8: 0, 9: 0   # 戊年、癸年起甲寅月（甲=0）
    }
    
    # 五鼠遁日起时表（甲己日起甲子时，乙庚日起丙子时...）
    DAY_HOUR_GAN_TABLE = {
        0: 0, 5: 0,  # 甲日(0)、己日(5)起甲子时（甲=0）
        1: 2, 6: 2,  # 乙日(1)、庚日(6)起丙子时（丙=2）
        2: 4, 7: 4,  # 丙日(2)、辛日(7)起戊子时（戊=4）
        3: 6, 8: 6,  # 丁日(3)、壬日(8)起庚子时（庚=6）
        4: 8, 9: 8   # 戊日(4)、癸日(9)起壬子时（壬=8）
    }
    
    # 月建表（节气对应的地支）
    SOLAR_TERM_TO_ZHI = {
        "立春": 2,  "雨水": 2,    # 寅月
        "惊蛰": 3,  "春分": 3,    # 卯月
        "清明": 4,  "谷雨": 4,    # 辰月
        "立夏": 5,  "小满": 5,    # 巳月
        "芒种": 6,  "夏至": 6,    # 午月
        "小暑": 7,  "大暑": 7,    # 未月
        "立秋": 8,  "处暑": 8,    # 申月
        "白露": 9,  "秋分": 9,    # 酉月
        "寒露": 10, "霜降": 10,   # 戌月
        "立冬": 11, "小雪": 11,   # 亥月
        "大雪": 0,  "冬至": 0,    # 子月
        "小寒": 1,  "大寒": 1     # 丑月
    }
    
    def __init__(self):
        self.cache_enabled = True
    
    @lru_cache(maxsize=200)
    def calculate_year_ganzhi(self, year: int) -> Tuple[str, str]:
        """
        计算年干支（以立春为界）
        
        Args:
            year: 年份
            
        Returns:
            Tuple[str, str]: (年干, 年支)
        """
        # 以甲子年（1984年）为基准
        base_year = 1984
        offset = year - base_year
        
        gan_index = offset % 10
        zhi_index = offset % 12
        
        return TIAN_GAN[gan_index], DI_ZHI[zhi_index]
    
    def calculate_month_ganzhi(self, dt: datetime, use_solar_terms: bool = True) -> Tuple[str, str]:
        """
        计算月干支（以节气为准）
        
        Args:
            dt: 时间（naive datetime）
            use_solar_terms: 是否使用节气分月
            
        Returns:
            Tuple[str, str]: (月干, 月支)
        """
        # 确保使用naive datetime
        if dt.tzinfo is not None:
            dt = dt.replace(tzinfo=None)
            
        if use_solar_terms:
            # 获取当前节气
            solar_term, _, _ = astro_calculator.get_current_solar_term(dt)
            
            # 根据节气确定月建（地支）
            month_zhi_index = self.SOLAR_TERM_TO_ZHI.get(solar_term, 2)  # 默认寅月
            month_zhi = DI_ZHI[month_zhi_index]
            
            # 获取年干索引
            year_gan, _ = self.calculate_year_ganzhi(dt.year)
            year_gan_index = TIAN_GAN.index(year_gan)
            
            # 使用五虎遁年起月法计算月干
            base_month_gan_index = self.YEAR_MONTH_GAN_TABLE.get(year_gan_index, 2)
            
            # 寅月为基准（索引2），计算当前月的干
            month_offset = (month_zhi_index - 2) % 12
            month_gan_index = (base_month_gan_index + month_offset) % 10
            month_gan = TIAN_GAN[month_gan_index]
            
        else:
            # 简化计算（使用公历月份）
            month_zhi_index = (dt.month + 1) % 12
            month_zhi = DI_ZHI[month_zhi_index]
            
            year_gan, _ = self.calculate_year_ganzhi(dt.year)
            year_gan_index = TIAN_GAN.index(year_gan)
            
            base_month_gan_index = self.YEAR_MONTH_GAN_TABLE.get(year_gan_index, 2)
            month_offset = (dt.month - 1) % 12
            month_gan_index = (base_month_gan_index + month_offset) % 10
            month_gan = TIAN_GAN[month_gan_index]
        
        return month_gan, month_zhi
    
    @lru_cache(maxsize=1000)
    def calculate_day_ganzhi(self, dt: datetime) -> Tuple[str, str]:
        """
        计算日干支
        
        Args:
            dt: 时间（naive datetime）
            
        Returns:
            Tuple[str, str]: (日干, 日支)
        """
        # 确保使用naive datetime
        if dt.tzinfo is not None:
            dt = dt.replace(tzinfo=None)
            
        # 以1900年1月1日为基准（甲戌日）- 修复了之前的庚子日错误
        base_date = datetime(1900, 1, 1)
        days_diff = (dt.date() - base_date.date()).days
        
        # 1900年1月1日是甲戌日，甲是第0个天干，戌是第10个地支
        base_gan_index = 0  # 甲
        base_zhi_index = 10  # 戌
        
        gan_index = (base_gan_index + days_diff) % 10
        zhi_index = (base_zhi_index + days_diff) % 12
        
        return TIAN_GAN[gan_index], DI_ZHI[zhi_index]
    
    def calculate_hour_ganzhi(self, dt: datetime, use_true_solar_time: bool = False, 
                            longitude: float = 116.4667) -> Tuple[str, str]:
        """
        计算时干支（使用五鼠遁日起时法）
        
        Args:
            dt: 时间（naive datetime）
            use_true_solar_time: 是否使用真太阳时
            longitude: 地理经度（用于真太阳时计算）
            
        Returns:
            Tuple[str, str]: (时干, 时支)
        """
        # 确保使用naive datetime
        if dt.tzinfo is not None:
            dt = dt.replace(tzinfo=None)
            
        # 如果使用真太阳时，需要转换
        if use_true_solar_time:
            dt = astro_calculator.calculate_true_solar_time(dt, longitude)
        
        # 计算时辰（地支）
        # 子时：23:00-01:00，丑时：01:00-03:00，...
        hour = dt.hour
        if hour == 23:
            hour_zhi_index = 0  # 子时
        else:
            hour_zhi_index = (hour + 1) // 2
        
        hour_zhi = DI_ZHI[hour_zhi_index]
        
        # 获取日干，用于五鼠遁日起时
        day_gan, _ = self.calculate_day_ganzhi(dt)
        day_gan_index = TIAN_GAN.index(day_gan)
        
        # 使用五鼠遁日起时法计算时干
        base_hour_gan_index = self.DAY_HOUR_GAN_TABLE.get(day_gan_index, 0)
        hour_gan_index = (base_hour_gan_index + hour_zhi_index) % 10
        hour_gan = TIAN_GAN[hour_gan_index]
        
        return hour_gan, hour_zhi
    
    def _get_hour_zhi_index(self, hour: int) -> int:
        """
        获取时辰地支索引
        
        Args:
            hour: 小时（0-23）
            
        Returns:
            int: 地支索引
        """
        # 时辰对应表
        # 23-1点：子时，1-3点：丑时，3-5点：寅时...
        if hour == 23:
            return 0  # 子时
        else:
            return (hour + 1) // 2
    
    def calculate_shi_chen(self, hour: int) -> str:
        """
        计算时辰名称
        
        Args:
            hour: 小时（0-23）
            
        Returns:
            str: 时辰名称
        """
        zhi_index = self._get_hour_zhi_index(hour)
        return DI_ZHI[zhi_index] + "时"
    
    def calculate_complete_ganzhi(self, dt: datetime, use_true_solar_time: bool = False,
                                longitude: float = 116.4667) -> Dict[str, str]:
        """
        计算完整的年月日时干支
        
        Args:
            dt: 时间
            use_true_solar_time: 是否使用真太阳时
            longitude: 经度（用于真太阳时计算）
            
        Returns:
            Dict[str, str]: 包含年月日时干支的字典
        """
        # 是否使用真太阳时
        if use_true_solar_time:
            dt = astro_calculator.calculate_true_solar_time(dt, longitude)
        
        # 计算各项干支
        year_gan, year_zhi = self.calculate_year_ganzhi(dt.year)
        month_gan, month_zhi = self.calculate_month_ganzhi(dt, use_solar_terms=True)
        day_gan, day_zhi = self.calculate_day_ganzhi(dt)
        hour_gan, hour_zhi = self.calculate_hour_ganzhi(dt, use_true_solar_time, longitude)
        
        # 计算时辰
        shi_chen = self.calculate_shi_chen(dt.hour)
        
        return {
            "year_gan": year_gan,
            "year_zhi": year_zhi,
            "month_gan": month_gan,
            "month_zhi": month_zhi,
            "day_gan": day_gan,
            "day_zhi": day_zhi,
            "hour_gan": hour_gan,
            "hour_zhi": hour_zhi,
            "shi_chen": shi_chen,
            "year_ganzhi": year_gan + year_zhi,
            "month_ganzhi": month_gan + month_zhi,
            "day_ganzhi": day_gan + day_zhi,
            "hour_ganzhi": hour_gan + hour_zhi
        }
    
    def validate_ganzhi(self, gan: str, zhi: str) -> bool:
        """
        验证干支组合的有效性
        
        Args:
            gan: 天干
            zhi: 地支
            
        Returns:
            bool: 是否有效
        """
        if gan not in TIAN_GAN or zhi not in DI_ZHI:
            return False
        
        gan_index = TIAN_GAN.index(gan)
        zhi_index = DI_ZHI.index(zhi)
        
        # 检查干支组合的奇偶性（甲子、乙丑...甲配偶数，乙配奇数）
        return (gan_index % 2) == (zhi_index % 2)
    
    def get_nayin(self, gan: str, zhi: str) -> str:
        """
        获取干支纳音
        
        Args:
            gan: 天干
            zhi: 地支
            
        Returns:
            str: 纳音
        """
        # 纳音表（简化版）
        nayin_table = {
            "甲子": "海中金", "乙丑": "海中金", "丙寅": "炉中火", "丁卯": "炉中火",
            "戊辰": "大林木", "己巳": "大林木", "庚午": "路旁土", "辛未": "路旁土",
            "壬申": "剑锋金", "癸酉": "剑锋金", "甲戌": "山头火", "乙亥": "山头火",
            "丙子": "涧下水", "丁丑": "涧下水", "戊寅": "城头土", "己卯": "城头土",
            "庚辰": "白蜡金", "辛巳": "白蜡金", "壬午": "杨柳木", "癸未": "杨柳木",
            "甲申": "泉中水", "乙酉": "泉中水", "丙戌": "屋上土", "丁亥": "屋上土",
            "戊子": "霹雳火", "己丑": "霹雳火", "庚寅": "松柏木", "辛卯": "松柏木",
            "壬辰": "长流水", "癸巳": "长流水", "甲午": "砂中金", "乙未": "砂中金",
            "丙申": "山下火", "丁酉": "山下火", "戊戌": "平地木", "己亥": "平地木",
            "庚子": "壁上土", "辛丑": "壁上土", "壬寅": "金箔金", "癸卯": "金箔金",
            "甲辰": "覆灯火", "乙巳": "覆灯火", "丙午": "天河水", "丁未": "天河水",
            "戊申": "大驿土", "己酉": "大驿土", "庚戌": "钗钏金", "辛亥": "钗钏金",
            "壬子": "桑柘木", "癸丑": "桑柘木", "甲寅": "大溪水", "乙卯": "大溪水",
            "丙辰": "沙中土", "丁巳": "沙中土", "戊午": "天上火", "己未": "天上火",
            "庚申": "石榴木", "辛酉": "石榴木", "壬戌": "大海水", "癸亥": "大海水"
        }
        
        ganzhi = gan + zhi
        return nayin_table.get(ganzhi, "未知")
    
    def format_ganzhi_display(self, ganzhi_info: Dict[str, str]) -> str:
        """
        格式化干支显示
        
        Args:
            ganzhi_info: 干支信息字典
            
        Returns:
            str: 格式化的干支显示
        """
        return (f"{ganzhi_info['year_ganzhi']}年 "
                f"{ganzhi_info['month_ganzhi']}月 "
                f"{ganzhi_info['day_ganzhi']}日 "
                f"{ganzhi_info['hour_ganzhi']}时")


# 创建全局实例
ganzhi_calculator = GanZhiCalculator()

# 公开的便捷函数
def calculate_ganzhi(dt: datetime, use_true_solar_time: bool = False, 
                    longitude: float = 116.4667) -> Dict:
    """
    计算完整干支信息
    
    Args:
        dt: 时间（naive datetime）
        use_true_solar_time: 是否使用真太阳时
        longitude: 地理经度
        
    Returns:
        Dict: 包含年月日时干支信息
    """
    return ganzhi_calculator.calculate_complete_ganzhi(dt, use_true_solar_time, longitude)


def get_year_ganzhi(year: int) -> Tuple[str, str]:
    """
    获取年干支（便捷函数）
    
    Args:
        year: 年份
        
    Returns:
        Tuple[str, str]: (年干, 年支)
    """
    return ganzhi_calculator.calculate_year_ganzhi(year)


def get_day_ganzhi(dt: datetime) -> Tuple[str, str]:
    """
    获取日干支（便捷函数）
    
    Args:
        dt: 时间
        
    Returns:
        Tuple[str, str]: (日干, 日支)
    """
    return ganzhi_calculator.calculate_day_ganzhi(dt) 