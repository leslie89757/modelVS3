#!/usr/bin/env python3
"""
奇门遁甲单独使用脚本
简单易用的奇门排盘和断事分析工具
"""

from datetime import datetime
import pytz

# 使用绝对导入避免相对导入问题
try:
    import qimen_calendar as calendar, ju, palace, rules
    from palace import PalaceEngine
except ImportError:
    # 如果直接导入失败，尝试相对导入
    try:
        from . import qimen_calendar as calendar, ju, palace, rules
        from .palace import PalaceEngine
    except ImportError:
        # 如果还是失败，尝试从当前目录导入
        import sys
        import os
        current_dir = os.path.dirname(__file__)
        if current_dir not in sys.path:
            sys.path.insert(0, current_dir)
        import qimen_calendar as calendar, ju, palace, rules
        from palace import PalaceEngine

def display_calendar_info(cal_info):
    """显示历法信息"""
    print("📋 历法信息:")
    print(f"   📅 公历: {cal_info['year']}年{cal_info['month']}月{cal_info['day']}日 {cal_info['hour']}时{cal_info['minute']}分")
    print(f"   🕐 时辰: {cal_info['shi_chen']}")
    print(f"   📆 节气: {cal_info['solar_term']}")
    print(f"   🌟 干支: {cal_info['year_gan']}{cal_info['year_zhi']}年 {cal_info['month_gan']}{cal_info['month_zhi']}月 {cal_info['day_gan']}{cal_info['day_zhi']}日 {cal_info['hour_gan']}{cal_info['hour_zhi']}时")
    print()

def display_ju_info(ju_number, is_yang, nine_palace):
    """显示奇门局信息"""
    print("🏰 奇门局信息:")
    print(f"   🎯 局数: {ju_number}")
    print(f"   ⚊ 阴阳: {'阳遁' if is_yang else '阴遁'}")
    print(f"   📜 局名: {nine_palace.get('ju_name', '未知')}")
    print(f"   🧭 值符: {nine_palace.get('zhifu', '未知')}")
    print(f"   ⭐ 值使: {nine_palace.get('zhishi', '未知')}")
    print()

def display_nine_palace(nine_palace):
    """显示九宫排盘"""
    print("🏯 九宫排盘:")
    palace_names = ["一宫(坎)", "二宫(坤)", "三宫(震)", "四宫(巽)", 
                   "五宫(中)", "六宫(乾)", "七宫(兑)", "八宫(艮)", "九宫(离)"]
    
    for i, palace_name in enumerate(palace_names):
        palace_key = f"palace_{i+1}"
        if palace_key in nine_palace:
            palace_data = nine_palace[palace_key]
            print(f"   🏛️  {palace_name}:")
            print(f"      天盘: {palace_data.get('tianpan', '无')}")
            print(f"      地盘: {palace_data.get('dipan', '无')}")
            print(f"      人盘: {palace_data.get('renpan', '无')}")
            print(f"      八神: {palace_data.get('bashen', '无')}")
            print(f"      门: {palace_data.get('men', '无')}")
            print(f"      星: {palace_data.get('xing', '无')}")
    print()

def display_analysis(analysis):
    """显示断事分析"""
    print("📊 奇门断事分析:")
    for analysis_type, results in analysis.items():
        if results:
            print(f"   📈 {analysis_type} ({len(results)} 项):")
            for i, result in enumerate(results, 1):
                print(f"      {i}. {result}")
    print()

def qimen_now():
    """当前时间奇门排盘"""
    print("🎯 奇门遁甲排盘")
    print("=" * 50)
    
    # 获取当前上海时间
    shanghai_tz = pytz.timezone("Asia/Shanghai")
    current_time = datetime.now(shanghai_tz)
    
    # 奇门排盘
    cal_info = calendar.from_datetime(current_time, "Asia/Shanghai")
    ju_number, is_yang = ju.get_ju(cal_info, "活盘")
    palace_engine = PalaceEngine()
    nine_palace = palace_engine.turn_pan(ju_number, is_yang)
    
    # 断事分析
    rules_engine = rules.create_default_engine()
    analysis = rules_engine.apply_all(nine_palace, cal_info)
    
    # 显示结果
    display_calendar_info(cal_info)
    display_ju_info(ju_number, is_yang, nine_palace)
    display_nine_palace(nine_palace)
    display_analysis(analysis)
    
    return cal_info, ju_number, is_yang, nine_palace, analysis

def qimen_custom_time(time_str):
    """指定时间奇门排盘"""
    print(f"🎯 奇门遁甲排盘: {time_str}")
    print("=" * 50)
    
    try:
        # 解析时间
        if isinstance(time_str, str):
            from dateutil import parser
            dt = parser.parse(time_str)
            # 如果没有时区信息，假设为上海时间
            if dt.tzinfo is None:
                shanghai_tz = pytz.timezone("Asia/Shanghai")
                dt = shanghai_tz.localize(dt)
        
        # 奇门排盘
        cal_info = calendar.from_datetime(dt, "Asia/Shanghai")
        ju_number, is_yang = ju.get_ju(cal_info, "活盘")
        palace_engine = PalaceEngine()
        nine_palace = palace_engine.turn_pan(ju_number, is_yang)
        
        # 断事分析
        rules_engine = rules.create_default_engine()
        analysis = rules_engine.apply_all(nine_palace, cal_info)
        
        # 显示结果
        display_calendar_info(cal_info)
        display_ju_info(ju_number, is_yang, nine_palace)
        display_nine_palace(nine_palace)
        display_analysis(analysis)
        
        return cal_info, ju_number, is_yang, nine_palace, analysis
        
    except Exception as e:
        print(f"❌ 时间解析错误: {e}")
        print("📝 支持的时间格式:")
        print("   - '2025-01-01 10:30:00'")
        print("   - '2025-01-01T10:30'")
        print("   - '2025/1/1 10:30'")
        return None

def interactive_qimen():
    """交互式奇门系统"""
    print("🔮 奇门遁甲交互式系统")
    print("=" * 50)
    
    while True:
        print("\n📋 选择操作:")
        print("1. 当前时间排盘")
        print("2. 指定时间排盘")
        print("3. 退出")
        
        choice = input("\n请输入选项 (1-3): ").strip()
        
        if choice == '1':
            print()
            qimen_now()
        elif choice == '2':
            time_input = input("\n请输入时间 (如: 2025-01-01 10:30): ").strip()
            if time_input:
                print()
                qimen_custom_time(time_input)
        elif choice == '3':
            print("\n👋 再见！")
            break
        else:
            print("❌ 无效选项，请重新选择")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) == 1:
        # 无参数，启动交互模式
        interactive_qimen()
    elif len(sys.argv) == 2:
        if sys.argv[1] == "now":
            # 当前时间排盘
            qimen_now()
        else:
            # 指定时间排盘
            qimen_custom_time(sys.argv[1])
    else:
        print("📖 使用方法:")
        print("   python3 qimen_only.py              # 交互模式")
        print("   python3 qimen_only.py now          # 当前时间排盘")
        print("   python3 qimen_only.py '2025-01-01 10:30'  # 指定时间排盘") 