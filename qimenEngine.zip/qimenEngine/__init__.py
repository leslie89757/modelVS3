"""
奇门遁甲排盘系统核心模块
"""

__version__ = "0.1.0"
__author__ = "QIGI" 